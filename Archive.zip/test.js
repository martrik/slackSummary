const utils = require('./utils.js');

utils.handleRequest({ channel_id: "C3D8YGLSH", user_id: "U02FRBZE9" }, function(err, res) {
});
